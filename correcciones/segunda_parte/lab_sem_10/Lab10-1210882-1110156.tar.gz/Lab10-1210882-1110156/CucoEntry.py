


class CucoEntry:
	def __init__(self,clave,valor):
		self.clave= str(clave)
		self.valor= str(valor)
	
	

