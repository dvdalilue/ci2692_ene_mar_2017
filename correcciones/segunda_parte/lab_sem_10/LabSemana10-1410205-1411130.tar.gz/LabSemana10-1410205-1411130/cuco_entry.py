class CucoEntry:
	def __init__(self,clave,valor):
		#Inicializa la clase cucoEntry
		self.crearCucoEntry(clave,valor)

	def crearCucoEntry(self,clave,valor):
		self.clave=clave
		self.valor=valor
