from cuco_table import CucoTable
import sys

def test_cucoTable():
	#Cliente para probar las funciones de la clase CucoTable implementadas en el laboratorio
	m=int(input("Introduzca el tamaño de la tabla de hash que desea: "))
	while m<=0:
		m=int(input("Introduzca el tamaño de la tabla de hash que desea: "))
	tabla=CucoTable(m)
	menustr="1. Agregar elemento a la tabla.\n2. Eliminar elemento de la tabla.\n3. Buscar con clave.\n4. Mostrar el contenido de la tabla.\n5. Mostrar opciones del menu.\n6. Salir del cliente."
	print(menustr)
	while True:
		op=int(input("Introduzca la opcion de menu que desea: "))
		while op not in range(1,7):
			op=int(input("Introduzca la opcion de menu que desea: "))
		if op==1:
			clave=input("Introduzca la clave del elemento: ")
			while len(clave)==0 or clave==" ":
				clave=input("Introduzca la clave del elemento: ")
			valor=input("Introduzca el valor asociado al elemento: ")
			while len(valor)==0 or valor==" ":
				valor=input("Introduzca el valor asociado al elemento: ")
			tabla.agregar(clave,valor)
		if op==2:
			clave=input("Introduzca la clave del elemento: ")
			while len(clave)==0 or clave==" ":
				clave=input("Introduzca la clave del elemento: ")
			eliminado=tabla.eliminar(clave)
			if eliminado==None:
				print("No se elimino ningun elemento.")
			else:
				print("El elemento eliminado tiene valor asociado "+ eliminado)
		if op==3:
			clave=input("Introduzca la clave del elemento: ")
			while len(clave)==0 or clave==" ":
				clave=input("Introduzca la clave del elemento: ")
			encontrado=tabla.buscar(clave)
			if encontrado==None:
				print("No se encontro ningun elemento.")
			else:
				print("El elemento tiene valor asociado "+ encontrado)
		if op==4:
			tabla.mostrar()
		if op==5:
			print(menustr)
		if op==6:
			sys.exit()

test_cucoTable()