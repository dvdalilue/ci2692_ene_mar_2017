""" Laboratorio Semana 10
# DESCRIPCIÓN: Cliente que prueba el correcto funcionamiento de
# la tabla de Hash Cuco implementada.
# Autor: Jesus Kauze y David Segura
# email: 12-10273@usb.ve y 13-11341@usb.ve
"""

from CucoTable import CucoTable

diccionario = CucoTable()
diccionario.CrearCucoTabla(9)
print("-----------AGREGANDO ELEMENTOS----------")
diccionario.Agregar("Segura","David Segura")
diccionario.Agregar("Kauze","Jesus Kauze")
diccionario.Agregar("Rodriguez","Manuel Rodriguez")
diccionario.Agregar("Hernandez","Jean Hernandez")
diccionario.Agregar("Lilue","David Lilue")
diccionario.Agregar("Colina","Cesar Colina")
diccionario.Agregar("Flavianni","Federico Flavianni")
diccionario.Agregar("Chang","Carolina Chang")
diccionario.Agregar("Perez","Hector Perez")
diccionario.Mostrar()
print("---CASO ERROR DE ENTEROS---")
diccionario.Agregar(2,"Hector")
print("-----------ELIMINANDO ELEMENTOS----------")
print("El elemento eliminado es: "+str(diccionario.Eliminar("Rodriguez")))
diccionario.Mostrar()
print("---OTRO---")
print("El elemento eliminado es: "+str(diccionario.Eliminar("Flavianni")))
diccionario.Mostrar()
print("---CASO ERROR: LA CLAVE NO ESTA---")
diccionario.Eliminar("Rodriguez")
print("-----------BUSCANDO ELEMENTOS----------")
print("El elemento buscado es: "+str(diccionario.Buscar("Segura")))
print("El elemento buscado es: "+str(diccionario.Buscar("Kauze")))
print("---CASO ERROR: LA CLAVE NO ESTA---")
diccionario.Buscar("hola")