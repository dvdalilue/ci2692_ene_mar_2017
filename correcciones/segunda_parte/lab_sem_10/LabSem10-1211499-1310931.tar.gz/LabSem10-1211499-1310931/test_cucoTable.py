from arrayT import ArrayT

from CucoEntry import *
from cuco_table import *
import hashlib, sys, random, argparse

# Descripcion: Cliente que prueba la abla de Hash tipo Cuco
#
# Autor: 	ORLANDO CHAPARRO 12-11499
#		    ANGEL MORANTE 13-10931


def test_cucoTable(m):
	datos = [random.randint(0,m) for x in range(0,m)]
	Tabla_de_Hash = CrearCucoTable(m)

	for i in range(len(datos)):
		c = str(datos[i]) # Clave a buscar
		if Tabla_de_Hash.Buscar(c) == None:
			# Si la clave buscada 'c' no existe, entonces se agrega
			# dicha clave con el string asociado 'CI2692'
			Tabla_de_Hash.Agregar("Clave: " + c, "Valor Asociado: " + str(i))

		else:
			# Si existe, entonces se elimina la clave
			e = crearCucoEntry(c,"CI2692")
			Tabla_de_Hash.Eliminar(e)	
		
		Tabla_de_Hash.mostrar()

# INICIAN PRUEBAS DE LAS TABLAS
if __name__ == "__main__":
	# Recibe el valor m introducido por terminal, recuerde:
	# python test_htable.py < m >
	"""parser = argparse.ArgumentParser(description="Tamano de la cola")
	parser.add_argument("-m", "--tamano",  metavar="NT",  type=int, default=1,
		help="tamano de la tabla de hash")"""
	m = int(sys.argv[1])
	test_cucoTable(m)
