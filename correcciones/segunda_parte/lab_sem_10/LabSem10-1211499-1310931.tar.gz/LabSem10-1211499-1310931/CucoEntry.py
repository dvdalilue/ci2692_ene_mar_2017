
# Descripcion: Implementa la clase CucoEntry, que posee dos campos: clave y valor.+
#
# Autor: 	ORLANDO CHAPARRO 12-11499
#		    ANGEL MORANTE 13-10931

# Atributos: clave: Clave que se asociara a un dato
#			 valor: valor asociado a la clave


class crearCucoEntry:
    def __init__(self,clave,valor):
        self.clave = clave
        self.valor = valor
