""" Algoritmos II .ene-mar 2017 
	fecha: 1/04/2017
    Descripcion:   NodoConver
	autores: Edymar Mijares 12-10882
	         Jose Carmona 11-10156

	correo: - edys.beccaria@gmail.com
		   - carmona621@hotmail.com
ultima edicion :30/03/2017"""

class NodoConver:
	def __init__(self, eC, eD, s, a):
		self.Clave = eC
		self.elemento = eD
		self.siguiente = s
		self.anterior = a
